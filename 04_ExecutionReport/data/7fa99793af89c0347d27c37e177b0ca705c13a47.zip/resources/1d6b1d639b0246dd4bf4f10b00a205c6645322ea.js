// Firebase Messaging Service Worker for background notifications
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js');

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyApJ09Xn1WWlNZqOurHALJfM99p-lPt6mg",
  authDomain: "tichi-app.firebaseapp.com",
  projectId: "tichi-app",
  storageBucket: "tichi-app.firebasestorage.app",
  messagingSenderId: "313420793236",
  appId: "1:313420793236:web:ba58abcfc4fb0f12c2bb81"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Get messaging instance
const messaging = firebase.messaging();

// Handle background messages
messaging.onBackgroundMessage((payload) => {
  console.log('[FCM] Received background message:', payload);

  const notificationTitle = payload.notification?.title || 'New Notification';
  const notificationOptions = {
    body: payload.notification?.body || payload.data?.message,
    icon: '/assets/images/favicon.ico',
    badge: '/assets/images/favicon.ico',
    tag: payload.data?.notificationId || 'default',
    data: payload.data,
    requireInteraction: false,
    silent: false
  };

  // Show notification
  return self.registration.showNotification(notificationTitle, notificationOptions);
});

// Handle notification click
self.addEventListener('notificationclick', (event) => {
  console.log('[FCM] Notification clicked:', event);
  
  event.notification.close();
  
  // Handle different actions
  if (event.action === 'close') {
    return;
  }
  
  // Handle navigation based on notification data
  const data = event.notification.data;
  if (data?.url) {
    event.waitUntil(
      clients.openWindow(data.url)
    );
  } else if (data?.type) {
    // Handle different notification types
    let url = '/notifications';
    switch (data.type) {
      case 'job_request':
        url = `/jobs/${data.jobId}`;
        break;
      case 'new_message':
        url = '/messages';
        break;
      case 'payment_success':
        url = '/profile?tabid=payments';
        break;
    }
    event.waitUntil(
      clients.openWindow(url)
    );
  } else {
    // Default: open the app
    event.waitUntil(
      clients.openWindow('/home')
    );
  }
});

// Handle notification close
self.addEventListener('notificationclose', (event) => {
  console.log('[FCM] Notification closed:', event);
});

// Handle push event (fallback for older browsers)
self.addEventListener('push', (event) => {
  console.log('[FCM] Push event received:', event);
  
  if (event.data) {
    const data = event.data.json();
    const notificationTitle = data.notification?.title || 'New Notification';
    const notificationOptions = {
      body: data.notification?.body || data.data?.message,
      icon: '/assets/images/favicon.ico',
      badge: '/assets/images/favicon.ico',
      tag: data.data?.notificationId || 'default',
      data: data.data,
      requireInteraction: false,
      silent: false
    };
    
    event.waitUntil(
      self.registration.showNotification(notificationTitle, notificationOptions)
    );
  }
});
